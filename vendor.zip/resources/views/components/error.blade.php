@error($name)
    <span class="text-danger border border-danger px-4 rounded">
        <i class="fas fa-exclamation-triangle"></i> {{ $message }}
    </span>
@enderror