<div id="loader-wrapper" style="display: none">
    <div id="loader">
        <div id="circle"></div>
    </div>
    <p id="loading-text">Cargando ... un momento ...</p>
</div>
