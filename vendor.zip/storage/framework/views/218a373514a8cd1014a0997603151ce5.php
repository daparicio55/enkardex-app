

<?php $__env->startSection('title', 'Dietas'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="col-sm-12 col-md-6">
            <h1><b>Dietas recomendadas</b></h1>
        </div>
        <div class="col-sm-12 col-md-6 text-right bg-secondary">
            <h5 class="pt-2 pr-2"><b>#<?php echo e(ceros($kardex->numero)); ?> - <?php echo e(Str::upper($kardex->paciente->apellidos)); ?>,
                    <?php echo e(Str::title($kardex->paciente->nombres)); ?></b></h5>
        </div>
    </div>
    <a href="<?php echo e(route('licenciados.kardexes.index')); ?>" class="btn btn-warning">
        <i class="fas fa-arrow-circle-left"></i> Regresar
    </a>
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'addday','title' => 'Agregar un dia de atencion','type' => 'primary','icon' => 'fas fa-calendar-day','route' => 'licenciados.kardexes.dias.store','parameter' => 'null','method' => 'POST'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('body', null, []); ?> 
            <div class="row">
                <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                <input type="hidden" name="local" value="dietas">
                <div class="col-sm-12 col-md-12">
                    <?php echo Form::label('fecha', 'Fecha', [null]); ?>

                    <?php echo Form::date('fecha', null, ['class' => 'form-control']); ?>

                </div>
            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('textbutton', null, []); ?> 
            Agregar día
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php $__currentLoopData = $kardex->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::resolve(['title' => ''.e(date('d-m-Y', strtotime($dia->fecha))).'','theme' => 'info','icon' => 'fas fa-calendar-alt','collapsible' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    
                     <?php $__env->slot('toolsSlot', null, []); ?> 
                        
                        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'addfoot-' . $dia->id,'title' => 'Agregar nueva dieta','type' => 'warning','icon' => 'fas fa-hamburger','route' => 'licenciados.kardexes.ddietas.store','method' => 'POST','parameter' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('body', null, []); ?> 
                                <input type="hidden" name="dia" value="<?php echo e($dia->id); ?>">
                                <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['id' => 'dietas','name' => 'dietas[]','label' => 'Seleccione las dietas para este día','labelClass' => 'text-dark','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione multiples dietas...','multiple' => true]); ?>
                                     <?php $__env->slot('prependSlot', null, []); ?> 
                                        <div class="input-group-text bg-gradient-warning">
                                            <i class="fas fa-utensils"></i>
                                        </div>
                                     <?php $__env->endSlot(); ?>
                                    <?php $__currentLoopData = $dietas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dieta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dieta->id); ?>"><?php echo e($dieta->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table mb-0 table-borderless">
                            <tbody>
                                <?php
                                    $ddietas = \App\Models\DiaDieta::where('dia_id', '=', $dia->id)->get();
                                ?>
                                <?php $__currentLoopData = $ddietas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ddieta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="pt-0 pb-1"><?php echo e($ddieta->dieta->nombre); ?></td>
                                        <td class="pt-0 pb-1"><?php echo e($ddieta->dieta->descripcion); ?></td>
                                        <td class="pb-0" style="width: 80px">
                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'delete-' . $dia->id.'-'.$ddieta->id,'title' => 'Confirmar Accion','type' => 'danger','icon' => 'fas fa-trash-alt','route' => 'licenciados.kardexes.ddietas.destroy','parameter' => $ddieta->id,'method' => 'DELETE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                 <?php $__env->slot('body', null, []); ?> 
                                                    <p class="text-danger mb-0">¿Esta seguro que desea eliminar esta dieta?</p>
                                                 <?php $__env->endSlot(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b)): ?>
<?php $component = $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b; ?>
<?php unset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/licenciados/kardexes/dietas/index.blade.php ENDPATH**/ ?>