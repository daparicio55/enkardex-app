<div>
    <!-- Simplicity is the ultimate sophistication. - Leonardo da Vinci -->
   
    <?php echo Form::label('via_id', 'Via', [null]); ?>

    <?php echo Form::select('via_id', $vias, null, ['class'=>'form-control']); ?>

</div>

<?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/components/via.blade.php ENDPATH**/ ?>