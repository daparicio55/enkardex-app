<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger border border-danger px-4 rounded">
        <i class="fas fa-exclamation-triangle"></i> <?php echo e($message); ?>

    </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/components/error.blade.php ENDPATH**/ ?>