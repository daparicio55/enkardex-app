
    <!-- It is never too late to be what you might have been. - George Eliot -->
    <?php if(session('info')): ?>
    <script>
        Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: '<?php echo e(session('info')); ?>',
        showConfirmButton: false,
        timer: 4500
        })
    </script>    
    <?php endif; ?>
    <?php if(session('error')): ?>
    <script>
        Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: '<?php echo e(session('error')); ?>',
        showConfirmButton: false,
        timer: 4500
        })
    </script>    
    <?php endif; ?>
<?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/components/alert.blade.php ENDPATH**/ ?>