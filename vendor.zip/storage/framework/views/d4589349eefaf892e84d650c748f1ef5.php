

<?php $__env->startSection('title', 'kardex'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Hojas de tratamiento terapeutico (KARDEX)</h1>
    <a href="<?php echo e(route('licenciados.kardexes.create')); ?>" class="btn btn-success mt-1">
        <i class="fas fa-plus-circle"></i> Nuevo
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr class="bg-info">
                        <th class="pb-1 pt-1" style="width: 50px">N°</th>
                        <th class="pb-1 pt-1">PACIENTE</th>
                        <th class="pb-1 pt-1">SERVICIO</th>
                        <th class="pb-1 pt-1 text-center" style="width: 50px">AMB.</th>
                        <th class="pb-1 pt-1 text-center" style="width: 100px">FECHA</th>
                        <th class="pb-1 pt-1 text-center" style="width: 100px">HORA</th>                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kardexes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kardex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="pb-0"><?php echo e(ceros($kardex->numero)); ?></td>
                            <td class="pb-0"><?php echo e(Str::upper($kardex->paciente->apellidoPaterno)); ?> <?php echo e(Str::upper($kardex->paciente->apellidoMaterno)); ?>, <?php echo e(Str::title($kardex->paciente->nombres)); ?></td>
                            <td class="pb-0"><?php echo e($kardex->servicio->nombre); ?></td>
                            <td class="pb-0 text-center"><?php echo e($kardex->ambiente->nombre); ?></td>
                            <td class="pb-0 text-center"><?php echo e(date('d-m-Y',strtotime($kardex->fingreso))); ?></td>
                            <td class="pb-0 text-center"><?php echo e(date('H:i:s',strtotime($kardex->hingreso))); ?></td>
                        </tr>
                        <tr>
                            <td colspan="6">
                                <?php echo Form::open(['route'=>'licenciados.kardexes.indicaciones.index','method'=>'get','class'=>'d-inline']); ?>

                                    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-pills"></i> 
                                    </button>
                                <?php echo Form::close(); ?>

                                
                                <?php echo Form::open(['route'=>'licenciados.kardexes.eauxiliares.index','method'=>'get','class'=>'d-inline']); ?>

                                    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-vials"></i>
                                    </button>
                                <?php echo Form::close(); ?>

                                <?php echo Form::open(['route'=>'licenciados.kardexes.dietas.index','method'=>'get','class'=>'d-inline']); ?>

                                    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                                    <button type="submit" class="btn btn-info">
                                        <i class="fas fa-utensils"></i>
                                    </button>
                                <?php echo Form::close(); ?>

                                <?php echo Form::open(['route'=>'licenciados.kardexes.procedimientos.index','method'=>'get','class'=>'d-inline']); ?>

                                    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                                    <button type="submit" class="btn btn-secondary">
                                        <i class="fas fa-procedures"></i>
                                    </button>
                                <?php echo Form::close(); ?>

                                <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'delete-'.$kardex->id,'title' => 'Confirmar Accion','type' => 'danger','icon' => 'fas fa-trash-alt','route' => 'licenciados.kardexes.destroy','parameter' => $kardex->id,'method' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                     <?php $__env->slot('body', null, []); ?> 
                                        <p>¿Esta seguro que desea eliminar este Kardex? Recuerde que tambien eliminara todos los detalles relacionados a esta</p>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/licenciados/kardexes/index.blade.php ENDPATH**/ ?>