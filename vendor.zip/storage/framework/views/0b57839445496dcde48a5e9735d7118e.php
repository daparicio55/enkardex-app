<!-- The biggest battle is the war against ignorance. - Mustafa Kemal Atatürk -->
<label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
<div class="input-group">
    <?php if(isset($pre)): ?>
        <div class="input-group-prepend">
            <?php echo e($pre); ?>

        </div>    
    <?php endif; ?>
    <input type="date" class="form-control" name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" value="<?php echo e($value); ?>">
    <?php if(isset($end)): ?>
        <div class="input-group-append">
            <?php echo e($end); ?>

            
        </div>    
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/components/inputdate.blade.php ENDPATH**/ ?>