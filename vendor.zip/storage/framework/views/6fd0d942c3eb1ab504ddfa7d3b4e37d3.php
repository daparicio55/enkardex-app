

<?php $__env->startSection('title', 'E Auxiliares'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="col-sm-12 col-md-6">
            <h1><b>Exámenes Auxiliares</b></h1>
        </div>
        <div class="col-sm-12 col-md-6 text-right bg-secondary">
            <h5 class="pt-2 pr-2"><b>#<?php echo e(ceros($kardex->numero)); ?> - <?php echo e(Str::upper($kardex->paciente->apellidos)); ?>,
                    <?php echo e(Str::title($kardex->paciente->nombres)); ?></b></h5>
        </div>
    </div>
    <a href="<?php echo e(route('licenciados.kardexes.index')); ?>" class="btn btn-warning">
        <i class="fas fa-arrow-circle-left"></i> Regresar
    </a>
    <?php echo Form::open([
        'route' => 'licenciados.kardexes.eauxiliares.create',
        'method' => 'get',
        'role' => 'search',
        'class' => 'd-inline',
    ]); ?>

    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
    <button type="submit" class="btn btn-success">
        <i class="fas fa-plus-circle"></i> Nuevo Exámen
    </button>
    <?php echo Form::close(); ?>

    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'addday','title' => 'Agregar un dia de atencion','type' => 'primary','icon' => 'fas fa-calendar-day','route' => 'licenciados.kardexes.dias.store','parameter' => 'null','method' => 'POST'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('body', null, []); ?> 
            <div class="row">
                <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                <input type="hidden" name="local" value="eauxiliares">
                <div class="col-sm-12 col-md-12">
                    <?php echo Form::label('fecha', 'Fecha', [null]); ?>

                    <?php echo Form::date('fecha', null, ['class' => 'form-control']); ?>

                </div>
            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('textbutton', null, []); ?> 
            Agregar día
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php $__currentLoopData = $eauxiliares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eauxiliare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::resolve(['title' => ''.e($eauxiliare->examene->nombre).'','theme' => 'info','icon' => 'fas fa-vials','collapsible' => 'collapsed'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    
                     <?php $__env->slot('toolsSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'delete-' . $eauxiliare->id,'title' => 'Confirmar Accion','type' => 'danger','icon' => 'fas fa-trash-alt','route' => 'licenciados.kardexes.eauxiliares.destroy','parameter' => $eauxiliare->id,'method' => 'DELETE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('body', null, []); ?> 
                                <p class="text-danger mb-0">¿Esta seguro que desea eliminar esta exámen del sistema?</p>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table mb-0 table-borderless">
                            <tbody>
                                <?php $__currentLoopData = $kardex->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="width: 150px" class="pt-0">
                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'solicitar-'.$eauxiliare->id.'-'.$dia->id,'type' => 'warning','icon' => 'fas fa-file-medical','title' => 'Confirmar Solicitud','route' => 'licenciados.kardexes.deas.store','method' => 'POST','parameter' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                 <?php $__env->slot('body', null, []); ?> 
                                                    <input type="hidden" name="eauxiliare" value="<?php echo e($eauxiliare->id); ?>">
                                                    <input type="hidden" name="dia" value="<?php echo e($dia->id); ?>">
                                                    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                                                    ¿Desea confirmar la solicitud del exámen?
                                                 <?php $__env->endSlot(); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                            <?php echo e(date('d-m-Y',strtotime($dia->fecha))); ?>

                                        </td>
                                        <?php
                                            $exs = App\Models\DiaEauxiliare::where('eauxiliare_id','=',$eauxiliare->id)
                                            ->where('dia_id','=',$dia->id)
                                            ->get();
                                        ?>
                                        <?php $__currentLoopData = $exs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center p-0">
                                                    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'eliminar-'.$eauxiliare->id.'-'.$dia->id.'-'.str_replace(':','',$ex->hora),'type' => 'danger','icon' => 'fa fa-trash','title' => 'Confirmar Acción','route' => 'licenciados.kardexes.deas.destroy','parameter' => $ex->id,'method' => 'DELETE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                         <?php $__env->slot('body', null, []); ?> 
                                                            <p class="text-left">¿Esta seguro que desea eliminar este exámen?</p>
                                                         <?php $__env->endSlot(); ?>
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'confirmar-'.$eauxiliare->id.'-'.$dia->id.'-'.str_replace(':','',$ex->hora),'type' => 'info','icon' => 'fa fa-check','title' => 'Confirmar Acción','route' => 'licenciados.kardexes.deas.update','parameter' => $ex->id,'method' => 'PUT'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                         <?php $__env->slot('body', null, []); ?> 
                                                            <p class="text-left">¿Desea marcar este examen como realizado o completado</p>
                                                         <?php $__env->endSlot(); ?>
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                <p class="m-0 p-0">
                                                    <span class="text-<?php echo e(horacolor($ex->hora)->color); ?>"><?php echo e(horacolor($ex->hora)->hora); ?></span>
                                                    <?php if($ex->estado == "realizado"): ?>
                                                        <i class="far fa-check-circle text-info"></i>
                                                    <?php else: ?>
                                                        <i class="fas fa-hourglass-half"></i>
                                                    <?php endif; ?>
                                                </p>
                                            </td>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b)): ?>
<?php $component = $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b; ?>
<?php unset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/licenciados/kardexes/eauxiliares/index.blade.php ENDPATH**/ ?>