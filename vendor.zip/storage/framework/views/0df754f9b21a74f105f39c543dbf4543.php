    <!-- Modal -->
    <div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="<?php echo e($id); ?>" aria-hidden="true">
        <?php if(isset($parameter)): ?>
            <?php echo Form::open(['route'=>[$route,$parameter],'method'=>$method]); ?>    
        <?php else: ?>
            <?php echo Form::open(['route'=>$route,'method'=>$method]); ?>

        <?php endif; ?>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-<?php echo e($type); ?>">
                    <h5 class="modal-title" id="<?php echo e($id); ?>"><i class="<?php echo e($icon); ?>"></i> <?php echo e($title); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                   <?php echo e($body); ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="far fa-times-circle"></i> Cerrar
                    </button>
                    <button type="submit" class="btn btn-<?php echo e($type); ?>">
                        <i class="far fa-check-circle"></i> Aceptar
                    </button>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-<?php echo e($type); ?>" data-toggle="modal" data-target="#<?php echo e($id); ?>">
        <i class="<?php echo e($icon); ?>"></i>
        <?php if(isset($textbutton)): ?>
            <?php echo e($textbutton); ?>    
        <?php endif; ?>
    </button>


<?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/components/modal.blade.php ENDPATH**/ ?>