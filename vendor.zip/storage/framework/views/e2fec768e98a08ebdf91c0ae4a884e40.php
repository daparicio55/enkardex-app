<div>
    <h1>Hello World!</h1>
    
</div>
<?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/livewire/counter.blade.php ENDPATH**/ ?>