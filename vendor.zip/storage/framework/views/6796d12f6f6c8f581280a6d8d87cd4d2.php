

<?php $__env->startSection('title', 'Procedimientos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Registrar Procedimientos</h1>
    <p>#<?php echo e($kardex->numero); ?> - <?php echo e(Str::upper($kardex->paciente->apellidos)); ?>,<?php echo e(Str::title($kardex->paciente->nombres)); ?>

    </p>
    <?php echo Form::open(['route' => 'licenciados.kardexes.procedimientos.index', 'method' => 'get']); ?>

    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
    <button type="submit" class="btn btn-warning mt-1">
        <i class="fas fa-arrow-circle-left"></i> Regresar
    </button>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php echo Form::open(['route' => 'licenciados.kardexes.procedimientos.store', 'method' => 'post']); ?>

            <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
            <?php if (isset($component)) { $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::resolve(['title' => 'Procedimientos','theme' => 'info','icon' => 'fas fa-procedures','collapsible' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="row">
                    <div class="col-sm-12">
                        <?php if (isset($component)) { $__componentOriginal72da2445730e8cbf7c876c0a12175ffc = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::resolve(['id' => 'procedimientos','name' => 'procedimientos[]','label' => 'Seleccione un Procedimiento','igroupSize' => 'md'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Select2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-placeholder' => 'Seleccione multiples examenes...','multiple' => true]); ?>
                             <?php $__env->slot('prependSlot', null, []); ?> 
                                <div class="input-group-text bg-gradient-info">
                                    <i class="fas fa-exclamation-circle"></i>
                                </div>
                             <?php $__env->endSlot(); ?>
                            <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($procedimiento->id); ?>"><?php echo e($procedimiento->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc)): ?>
<?php $component = $__componentOriginal72da2445730e8cbf7c876c0a12175ffc; ?>
<?php unset($__componentOriginal72da2445730e8cbf7c876c0a12175ffc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal7ec225ec96001a00becbb6d24d977476 = $component; } ?>
<?php $component = App\View\Components\Error::resolve(['name' => 'procedimientos'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Error::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ec225ec96001a00becbb6d24d977476)): ?>
<?php $component = $__componentOriginal7ec225ec96001a00becbb6d24d977476; ?>
<?php unset($__componentOriginal7ec225ec96001a00becbb6d24d977476); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7 = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Textarea::resolve(['name' => 'descripcion','label' => 'Descripcion del motivo del procedimiento','labelClass' => 'text-dark','igroupSize' => 'sm'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rows' => '5','placeholder' => 'ingrese texto...']); ?>
                             <?php $__env->slot('prependSlot', null, []); ?> 
                                <div class="input-group-text bg-info">
                                    <i class="fas fa-lg fa-file-alt"></i>
                                </div>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7)): ?>
<?php $component = $__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7; ?>
<?php unset($__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7); ?>
<?php endif; ?>
                    </div>
                </div>
                 <?php $__env->slot('footerSlot', null, []); ?> 
                    <button type="submit" class="btn btn-info">
                        <i class="fas fa-save"></i> Guardar
                    </button>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b)): ?>
<?php $component = $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b; ?>
<?php unset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b); ?>
<?php endif; ?>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/licenciados/kardexes/procedimientos/create.blade.php ENDPATH**/ ?>