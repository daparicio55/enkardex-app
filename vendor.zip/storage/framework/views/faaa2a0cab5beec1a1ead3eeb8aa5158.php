

<?php $__env->startSection('title', 'Medicamentos'); ?>

<?php $__env->startSection('content_header'); ?>

    <div class="row mb-1">
        <div class="col-sm-12 col-md-6">
            <h1><b>Medicamentos</b></h1>
        </div>
        <div class="col-sm-12 col-md-6 text-right bg-secondary">
            <h5 class="pt-2 pr-2"><b>#<?php echo e(ceros($kardex->numero)); ?> - <?php echo e(Str::upper($kardex->paciente->apellidoPaterno)); ?> <?php echo e(Str::upper($kardex->paciente->apellidoMaterno)); ?>,
                    <?php echo e(Str::title($kardex->paciente->nombres)); ?></b></h5>
        </div>
    </div>
    <a href="<?php echo e(route('licenciados.kardexes.index')); ?>" class="btn btn-warning">
        <i class="fas fa-arrow-circle-left"></i>
    </a>
    <?php echo Form::open([
        'route' => 'licenciados.kardexes.indicaciones.create',
        'method' => 'get',
        'role' => 'search',
        'class' => 'd-inline',
    ]); ?>

    <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
    <button type="submit" class="btn btn-success">
        <i class="fas fa-plus-circle"></i>
    </button>
    <?php echo Form::close(); ?>


    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'addday','title' => 'Agregar un dia de atencion','type' => 'primary','icon' => 'fas fa-calendar-day','route' => 'licenciados.kardexes.dias.store','parameter' => 'null','method' => 'POST'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('body', null, []); ?> 
            <div class="row">
                <input type="hidden" name="kardex" value="<?php echo e($kardex->id); ?>">
                <input type="hidden" name="local" value="indicaciones">
                
                <div class="col-sm-12 col-md-6">
                    <?php echo Form::label('dias', 'Dias creados', [null]); ?>

                    <ol>
                        <?php $__currentLoopData = $kardex->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(date('d-m-Y',strtotime($dia->fecha))); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
                <div class="col-sm-12 col-md-6">
                    <?php echo Form::label('add', 'Agregar días', [null]); ?>

                    <select name="add" id="add" class="form-control">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>



            </div>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('textbutton', null, []); ?> 
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
    <?php
        $config = [
            'placeholder' => 'Seleccione multiples medicamentos...',
        ];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <?php $__currentLoopData = $kardex->indicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $indicacione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b = $component; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::resolve(['title' => ''.e($indicacione->medicamento->denominacion).' - '.e($indicacione->medicamento->especificaciones).'','theme' => 'info','icon' => 'fas fa-lg fa-pills','collapsible' => 'collapsed'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    
                     <?php $__env->slot('toolsSlot', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'delete-' . $indicacione->id,'title' => 'Confirmar Accion','type' => 'danger','icon' => 'fas fa-trash-alt','route' => 'licenciados.kardexes.indicaciones.destroy','parameter' => $indicacione->id,'method' => 'DELETE'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('body', null, []); ?> 
                                <p class="text-danger mb-0">¿Esta seguro que desea eliminar esta indicación del sistema?</p>
                             <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                    
                    <?php echo Form::model($indicacione, [
                        'route' => ['licenciados.kardexes.indicaciones.update', $indicacione->id],
                        'method' => 'PUT',
                    ]); ?>

                    <div class="row">
                        <div class="col-sm-6 col-md-3">
                            <?php if (isset($component)) { $__componentOriginal4f58a8f370438027ab70aa5f8157f78f = $component; } ?>
<?php $component = App\View\Components\Via::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('via'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Via::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f58a8f370438027ab70aa5f8157f78f)): ?>
<?php $component = $__componentOriginal4f58a8f370438027ab70aa5f8157f78f; ?>
<?php unset($__componentOriginal4f58a8f370438027ab70aa5f8157f78f); ?>
<?php endif; ?>
                        </div>
                        <div class="col-sm-6 col-md-4">
                            <?php echo Form::label('dosis', 'Dosis', [null]); ?>

                            <?php echo Form::text('dosis', null, ['class' => 'form-control']); ?>

                        </div>
                        <div class="col-sm-6 col-md-3">
                            <?php if (isset($component)) { $__componentOriginal1a6cfa3f033efc10aed7915f16b4d35f = $component; } ?>
<?php $component = App\View\Components\Frecuencia::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frecuencia'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frecuencia::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a6cfa3f033efc10aed7915f16b4d35f)): ?>
<?php $component = $__componentOriginal1a6cfa3f033efc10aed7915f16b4d35f; ?>
<?php unset($__componentOriginal1a6cfa3f033efc10aed7915f16b4d35f); ?>
<?php endif; ?>
                        </div>

                        <div class="col-sm-6 col-md-1">
                            <?php echo Form::label(null, 'Guardar', ['class' => 'd-block']); ?>

                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-save"></i>
                            </button>
                        </div>
                    </div>
                     <?php $__env->slot('footerSlot', null, []); ?> 
                        <div class="table-responsive">
                            <table class="table mb-0 table-borderless">
                                <tbody>
                                    <?php
                                        $hora = null;
                                    ?>
                                    <?php if(isset($indicacione->frecuencia)): ?>
                                        <?php $__currentLoopData = $kardex->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="width: 110px" class="text-center p-0 m-0 h5">
                                                    <b><?php echo e(date('d-m-Y', strtotime($dia->fecha))); ?></b></td>
                                                <?php if($loop->first): ?>
                                                    <?php
                                                        $horainicio = Carbon\Carbon::parse($dia->fecha . ' ' . $kardex->hingreso);
                                                        $horasuma = Carbon\Carbon::parse($dia->fecha . ' ' . $kardex->hingreso);
                                                    ?>
                                                    <?php while($horasuma->isSameDay($horainicio)): ?>
                                                        <td class="text-center text-<?php echo e(horacolor($horasuma)->color); ?> p-0">
                                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'noaplica-' .
                                                                $indicacione->id .
                                                                '-' .
                                                                $dia->id .
                                                                '-' .
                                                                str_replace(':', '', horacolor($horasuma)->hora),'title' => 'Confirmar acción','type' => 'secondary','icon' => 'fas fa-ban','route' => 'licenciados.kardexes.dins.store','parameter' => $kardex->id,'method' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                                 <?php $__env->slot('body', null, []); ?> 
                                                                    <input type="hidden" name="dia_id"
                                                                        value="<?php echo e($dia->id); ?>">
                                                                    <input type="hidden" name="indicacione_id"
                                                                        value="<?php echo e($indicacione->id); ?>">
                                                                    <input type="hidden" name="hora"
                                                                        value="<?php echo e(horacolor($horasuma)->hora); ?>">
                                                                    <input type="hidden" name="tipo" value="no aplica">
                                                                    <p class="text-left text-dark">Esto marcara como <span><b>NO
                                                                                APLICA</b></span>, ¿Desea continuar?...</p>
                                                                 <?php $__env->endSlot(); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'done-' .
                                                                $indicacione->id .
                                                                '-' .
                                                                $dia->id .
                                                                '-' .
                                                                str_replace(':', '', horacolor($horasuma)->hora),'title' => 'Confirmar acción','type' => 'info','icon' => 'far fa-check-circle','route' => 'licenciados.kardexes.dins.store','parameter' => $kardex->id,'method' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                                 <?php $__env->slot('body', null, []); ?> 
                                                                    <input type="hidden" name="dia_id"
                                                                        value="<?php echo e($dia->id); ?>">
                                                                    <input type="hidden" name="indicacione_id"
                                                                        value="<?php echo e($indicacione->id); ?>">
                                                                    <input type="hidden" name="hora"
                                                                        value="<?php echo e(horacolor($horasuma)->hora); ?>">
                                                                    <input type="hidden" name="tipo" value="aplicado">
                                                                    <p class="text-left text-dark">Esto marcara
                                                                        <b>SUMINISTRADA</b>, ¿Desea continuar?...</p>
                                                                 <?php $__env->endSlot(); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                            
                                                            <p>
                                                                <?php echo e(horacolor($horasuma)->hora); ?>

                                                                <?php if(estadohora($dia->id, $indicacione->id, horacolor($horasuma)->hora) == 'no aplica'): ?>
                                                                    <small class="text-secondary"><i
                                                                            class="fas fa-ban"></i></small>
                                                                <?php endif; ?>
                                                                <?php if(estadohora($dia->id, $indicacione->id, horacolor($horasuma)->hora) == 'aplicado'): ?>
                                                                    <small class="text-info"><i
                                                                            class="far fa-check-circle"></i></small>
                                                                <?php endif; ?>
                                                            </p>

                                                        </td>
                                                        <?php
                                                            $horasuma->addHours($indicacione->frecuencia);
                                                            $hora = $horasuma;
                                                        ?>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <?php
                                                        $horasuma = $hora->copy();
                                                    ?>
                                                    <?php while($horasuma->isSameDay($hora)): ?>
                                                        <td class="text-center text-<?php echo e(horacolor($horasuma)->color); ?> p-0">
                                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'noaplica-' .
                                                                $indicacione->id .
                                                                '-' .
                                                                $dia->id .
                                                                '-' .
                                                                str_replace(':', '', horacolor($horasuma)->hora),'title' => 'Confirmar acción','type' => 'secondary','icon' => 'fas fa-ban','route' => 'licenciados.kardexes.dins.store','parameter' => $kardex->id,'method' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                                 <?php $__env->slot('body', null, []); ?> 
                                                                    <input type="hidden" name="dia_id"
                                                                        value="<?php echo e($dia->id); ?>">
                                                                    <input type="hidden" name="indicacione_id"
                                                                        value="<?php echo e($indicacione->id); ?>">
                                                                    <input type="hidden" name="hora"
                                                                        value="<?php echo e(horacolor($horasuma)->hora); ?>">
                                                                    <input type="hidden" name="tipo" value="no aplica">
                                                                    <p class="text-left text-dark">Esto marcara como
                                                                        <span><b>NO APLICA</b></span>, ¿Desea continuar?...</p>
                                                                 <?php $__env->endSlot(); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                            <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['id' => 'done-' .
                                                                $indicacione->id .
                                                                '-' .
                                                                $dia->id .
                                                                '-' .
                                                                str_replace(':', '', horacolor($horasuma)->hora),'title' => 'Confirmar acción','type' => 'info','icon' => 'far fa-check-circle','route' => 'licenciados.kardexes.dins.store','parameter' => $kardex->id,'method' => 'null'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                                 <?php $__env->slot('body', null, []); ?> 
                                                                    <input type="hidden" name="dia_id"
                                                                        value="<?php echo e($dia->id); ?>">
                                                                    <input type="hidden" name="indicacione_id"
                                                                        value="<?php echo e($indicacione->id); ?>">
                                                                    <input type="hidden" name="hora"
                                                                        value="<?php echo e(horacolor($horasuma)->hora); ?>">
                                                                    <input type="hidden" name="tipo" value="aplicado">
                                                                    <p class="text-left text-dark">Esto marcara
                                                                        <b>SUMINISTRADA</b>, ¿Desea continuar?...</p>
                                                                 <?php $__env->endSlot(); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
                                                            <p class="mb-0">
                                                                <?php echo e(horacolor($horasuma)->hora); ?>

                                                                <?php if(estadohora($dia->id, $indicacione->id, horacolor($horasuma)->hora) == 'no aplica'): ?>
                                                                    <small class="text-secondary"><i
                                                                            class="fas fa-ban"></i></small>
                                                                <?php endif; ?>
                                                                <?php if(estadohora($dia->id, $indicacione->id, horacolor($horasuma)->hora) == 'aplicado'): ?>
                                                                    <small class="text-info"><i
                                                                            class="far fa-check-circle"></i></small>
                                                                <?php endif; ?>
                                                            </p>
                                                        </td>
                                                        <?php
                                                            $horasuma->addHours($indicacione->frecuencia);
                                                        ?>
                                                    <?php endwhile; ?>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                     <?php $__env->endSlot(); ?>
                    <?php echo Form::close(); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b)): ?>
<?php $component = $__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b; ?>
<?php unset($__componentOriginale2b5538aaf81eaeffb0a99a88907fd7b); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dave\Desktop\Laravel Proyectos\enkardex-app\resources\views/licenciados/kardexes/indicaciones/index.blade.php ENDPATH**/ ?>